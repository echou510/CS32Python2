f = open("usdeclar.txt", "r")
ch=f.read(1)
count = 0
while ch:
    if ch.islower() or ch.isupper():
        count += 1
    print(ch, end="")
    ch=f.read(1)

print()
print("Total letter count for ", "usdeclar.txt", " is ", count)
f.close()

