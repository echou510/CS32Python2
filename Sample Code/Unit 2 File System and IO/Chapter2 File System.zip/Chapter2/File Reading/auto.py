f = open("auto-mpg.txt", "r")
lines = f.readlines()    # lines is a list of line strings
cars = []
for line in lines:
    fields = line.split()
    for i in range(9, len(fields)):   # merging the whole string in "" together
        fields[8] += " " + fields[i]
    model = []
    ct = 0
    for data in fields:               # strip of whitespaces for each data filed
        fields[ct] = data.strip()
        ct += 1
    try:
        ct = 0
        model.append(float(fields[ct]))
        ct += 1
        model.append(int(fields[ct]))
        ct += 1
        model.append(float(fields[ct]))
        ct += 1
        model.append(float(fields[ct]))
        ct += 1
        model.append(float(fields[ct]))
        ct += 1
        model.append(float(fields[ct]))
        ct += 1
        model.append(int(fields[ct]))
        ct += 1
        model.append(int(fields[ct]))
        ct += 1
        fields[ct] = fields[ct][1:len(fields[ct])-1] # takes out the "  " marks
        model.append(fields[ct])
    except:
        pass
    finally:
        print(model)
        cars.append(model)
#print(cars)
f.close()
