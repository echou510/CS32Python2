f = open("num.txt", "r")
tokens=f.read().split()
for token in tokens:
    token = token.strip()
    print(token, end=": ")
    try:
        if len(token)!=0:
            num = int(token)
            print(num)
    except:
        print("Error Input Format!!!")
f.close()



