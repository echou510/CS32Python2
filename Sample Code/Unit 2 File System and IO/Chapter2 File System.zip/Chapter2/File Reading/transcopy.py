f = open("usdeclar.txt", "r")
g = open("undeclarcopy.txt", "w")
lines = f.readlines()    # lines is a list of line strings
count = 0
for line in lines:
    count += 1
    g.write("Line "+str(count)+": "+line)

f.close()
g.close()


