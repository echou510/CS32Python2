f = open("usdeclar.txt", "r")
tokens=f.read().split()
count = 0
for token in tokens:
    token = token.strip()
    try:
        if len(token)!=0:
            count += 1
            if count % 20 != 0: print(token, end=" ")
            else: print(token)
    except:
        print("Error Input Format!!!")
print("usdeclar.txt has ", count, " words.")
f.close()

