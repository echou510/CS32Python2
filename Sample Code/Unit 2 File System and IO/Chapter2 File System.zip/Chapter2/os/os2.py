import os
files = [x for x in os.listdir() if x.endswith(".py")]
for f in files:
    print(f)

    