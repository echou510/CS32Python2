import os
currentDir = os.getcwd()
print("Current working direcotry: ", currentDir)
arr = os.listdir()
for f in arr:
    print("File: ", arr)

    