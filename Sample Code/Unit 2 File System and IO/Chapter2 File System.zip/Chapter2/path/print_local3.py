path = "C:\\Eric_Chou\\Python Course\\Python Object-Oriented Programming with Libraries\\PyDev\\U2 IO System\\Chapter2\\path"
file_name = "print_local2.py"
filename = path+"\\"+file_name

print("Absolute Path:", filename)
f = open(filename, "r")
file_string = f.read()
print("Print file: ")
print(file_string)
f.close()

names = filename.split("\\")
fname = names[len(names)-1]   # local file name
print("Local Path:", fname)
f = open(fname, "r")
file_string = f.read()
print("Print file: ")
print(file_string)
f.close()

fname2 = ".\\" + fname
print("Relative Path: ", fname2)
f = open(fname, "r")
file_string = f.read()
print("Print file: ")
print(file_string)
f.close()

