from pathlib import Path
def sub_dir(d):
    s = [x for x in d.iterdir() if x.is_dir()]
    for dd in s:
        print(dd)
        sub_dir(dd)

# put a correct directory in root
root = Path("C:\\Eric_Chou\\Python Course\\Python Object-Oriented Programming with Libraries\\PyDev\\U2 IO System")
sub_dir(root)


