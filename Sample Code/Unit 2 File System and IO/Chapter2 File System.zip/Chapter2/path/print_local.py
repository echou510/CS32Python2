f = open("print_local.py", "r")
file_string = f.read()              # lines is a list of line strings
print("Print file: ")
print(file_string)
f.close()

