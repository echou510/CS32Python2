path = "C:\\Eric_Chou\\Python Course\\Python Object-Oriented Programming with Libraries\\PyDev\\U2 IO System\\Chapter2\\path"
file_name = "print_local2.py"
filename = path+"\\"+file_name

f = open(filename, "r")
file_string = f.read()              # lines is a list of line strings
print("Print file: ")
print(file_string)
f.close()

