# list all directory under a directory
from pathlib import Path
root = Path("C:\\")
sub_directory = [x for x in root.iterdir() if x.is_dir()]

for d in sub_directory:
    print(d)

