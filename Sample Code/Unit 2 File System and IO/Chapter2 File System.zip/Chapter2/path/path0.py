from pathlib import Path

directory = Path(".")
filepath = directory / "path0.py"

print("File Path: ", filepath)
print()
print()

if filepath.exists():
    with open(filepath, "r") as f:
        fstring = f.read()
        print(fstring)
        f.close()

