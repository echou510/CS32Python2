from pathlib import Path

directory = Path(".")
filepath = directory / "path1.py"

print("Check if the directory exists: ", directory.exists())
print("Check if Current directory is a directory: ", directory.is_dir())
print("Check if the filepath exists: ", filepath.exists())
print("Check if Current filepath is a directory: ", filepath.is_dir())

p = Path("path1.py")
print("Check if path1.py exists: ", p.exists())
print("Check if path1.py is a directory: ", directory.is_dir())

if filepath.exists():
    with open(filepath, "r") as f:
        fstring = f.read()
        print(fstring)
        f.close()

