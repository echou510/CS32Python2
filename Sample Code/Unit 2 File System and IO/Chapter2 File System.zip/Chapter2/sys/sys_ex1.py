import sys

print("Scipt name: ", sys.argv[0])
print(len(sys.argv))

# run under windows