f = open("aa.txt", "r")
lines = f.readlines()    # lines is a list of line strings
print("Print file in list format: ")
print(lines)

all_lines = ""
for line in lines:
    all_lines += line

print("Print file as a long string: ")
print(all_lines)
f.close()

