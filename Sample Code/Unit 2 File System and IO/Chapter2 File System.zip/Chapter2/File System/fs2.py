f = open("aa.txt", "r")
lines = f.readlines()    # lines is a list of line strings
for line in lines:
    line = line.strip()   # string is immutable.  Therefore, line.strip() won't work.
    print(line, end=" ")
f.close()

