f = open("aa.txt", "r")
ch=f.read(1)
while ch:
    print(ch, end=" ")              # print extra space to show the date is character by character
    ch=f.read(1)
f.close()

