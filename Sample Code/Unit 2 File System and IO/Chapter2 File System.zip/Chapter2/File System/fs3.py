f = open("aa.txt", "r")
tokens=f.read().split()
for token in tokens:
    print("Token", token)              # print extra space to show the date is character by character
f.close()





