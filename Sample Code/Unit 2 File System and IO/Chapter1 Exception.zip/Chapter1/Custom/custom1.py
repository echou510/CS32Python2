raise SyntaxError("Sorry, my fault!")


