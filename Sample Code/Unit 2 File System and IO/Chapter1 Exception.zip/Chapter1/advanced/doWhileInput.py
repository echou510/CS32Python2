done = False
while not done:
    try:
        num = int(input("Enter an integer (or exit): "))
        print("%d is a valid integer." % num)
    except ValueError:
        done = True

