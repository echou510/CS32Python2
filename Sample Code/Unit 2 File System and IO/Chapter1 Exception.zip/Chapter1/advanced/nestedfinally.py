def func3():
    try:
        print("Tried Function 3")
        x = 9 / 0
    finally:
        print("In finally 3")
def func2():
    try:
        print("Tried Function 2")
        func3()
    finally:
        print("In finally 2")
def func1():
    try:
        print("Tried Function 1")
        func2()
    finally:
        print("In finally 1")
def main():
    try:
        print("Tried Function main()")
        func1()
    finally:
        print("In finally main()")
if __name__ == "__main__":
    main()

