f = open("data.txt", "r")
i=0
try:
    for a in f.readlines():
        i += 1
        print("Line ", i, ": ", int(a))
except EOFError:
    pass

f.close()

