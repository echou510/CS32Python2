f = open("data.txt", "r")
i=0
while True:
    try:
        a = int(f.readline())
    except ValueError:
        break
    else:
        i += 1
        print("Line ", i, ": ", a)
f.close()



