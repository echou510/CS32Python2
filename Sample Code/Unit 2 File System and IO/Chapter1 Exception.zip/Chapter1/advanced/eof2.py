f = open("data.txt", "r")
i=0
a = f.readline()
while a:
    i+=1
    print("Line ", i, ": ", int(a))
    a = f.readline()
f.close()


