def func3():
    try:
        print("Tried Function 3")
        x = 9 / 0
    except:
        print("Handled in Except 3")
def func2():
    try:
        print("Tried Function 2")
        func3()
    except:
        print("Handled in Except 2")
def func1():
    try:
        print("Tried Function 1")
        func2()
    except:
        print("Handled in Except 1")
def main():
    try:
        print("Tried Function main()")
        func1()
    except:
        print("Handled in Except main()")
if __name__ == "__main__":
    main()

    