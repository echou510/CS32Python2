# oops.py
#
# ICS 32 Fall 2017
# Code Example
#
# This module contains a Python program that always crashes.  Run this
# module and take a look at its output (a traceback).  A valuable skill
# as a Python programmer is the ability to read a traceback and use it
# to help diagnose the cause of unexpected crashes.
def f():
    x = 3
    g(x)
def g(n):
    print(len(n))
if __name__ == '__main__':
    f()


