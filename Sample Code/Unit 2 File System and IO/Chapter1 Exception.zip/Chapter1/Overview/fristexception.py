x = int(input("Enter the nominator:  "))
y = int(input("Enter the denominator:"))

try:
	a = x / y
except ZeroDivisionError:
	print("?")
else:
	print("a = ", a)
finally:
	print("finally")

    