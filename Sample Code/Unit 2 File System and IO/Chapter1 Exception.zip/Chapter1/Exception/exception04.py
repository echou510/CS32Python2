try:
    f= open("data.txt", "r")
    print("file opened")
finally:
    f.close()
    print("file closed.")

    