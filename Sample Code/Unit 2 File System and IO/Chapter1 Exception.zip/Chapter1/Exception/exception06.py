def f(x,y):
    assert x > 0, "x must be positve"
    assert y < 0, "y must be negative"
    return y**x

print(f(4, -3))
f(-3, -4)




