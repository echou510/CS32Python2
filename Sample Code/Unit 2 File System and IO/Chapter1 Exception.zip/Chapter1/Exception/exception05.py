try:
    raise KeyboardInterrupt
finally:
    print("Propagate")
    raise

