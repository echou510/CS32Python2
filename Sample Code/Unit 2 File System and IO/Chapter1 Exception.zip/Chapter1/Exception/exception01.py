def division(x, y):
    try:
        return x/y
    except ZeroDivisionError:
        print("division by zero")

division(3, 0)
print(division(5, 2))
division(5, 0)


