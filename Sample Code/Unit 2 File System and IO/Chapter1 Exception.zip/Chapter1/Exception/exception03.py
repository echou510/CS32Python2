try:
    print(3/0)
finally: print("finish")

