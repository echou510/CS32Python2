def div(x, y):
    try:
        if y==0: raise "zero"    # raise is similar to throw in Java
        return x/y
    except: print("ZERO")

print(div(3, 4))
div(3, 0)

