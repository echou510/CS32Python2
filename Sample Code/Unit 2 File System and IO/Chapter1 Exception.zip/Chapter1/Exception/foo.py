def foo():
    return 14

def bar():
    b1 = 3 * foo()
    return bi

def example():
    try:
        answer = bar()
        print('The answer is {}'.format(answer))
    except:
        print('ERROR')


example()