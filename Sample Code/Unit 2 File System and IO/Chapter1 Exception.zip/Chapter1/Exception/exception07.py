myException = "String"
try:
    raise(myException)    # need to use parenthese for python 3
except:                   # to catch string exception, don't use "expect myException"
    print("caught")

#raise(myException)

