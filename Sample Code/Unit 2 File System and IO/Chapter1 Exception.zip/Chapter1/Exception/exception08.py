class General(BaseException):               # Exception class need to inherit BaseException (Base Exception is like Exception in Java)
    pass
class Specific1(General):
    pass
class Specific2(General):
    pass
def raiser0():
    X = General()                           # raise superclass instance
    raise(X)                                # python 2.x raise X
def raiser1():
    raise(Specific1)                        # raise subclass instance
def raiser2():
    X = Specific2()                         # raise different subclass instance
    raise(X)                                # python 2.x raise X
for func in (raiser0, raiser1, raiser2):
    try: func()
    except General:
        import sys
        print('caught:', sys.exc_info())   # Python 2.x: sys.exc_type, Python 3.x: sys.exc_info()
    except:
        print("All other types")

        
