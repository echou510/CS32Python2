def func(**kwargs):
    print("Item list:")
    for (key, value) in kwargs.items():
        print("%s : %d" % (key, value))
    print("Iteritem List:")
    for t in kwargs.items():
        print("%s : %d" % (t[0], t[1]))

func(age=13, score=95)


