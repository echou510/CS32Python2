def max(*args):
    n = len(args)
    m = args[0]
    for i in range(n):
        if args[i] > m:
            m = args[i]
    return m

print(max(3, 4, 6, 7,2, 6, 9, 2, 13, 4, 5, 6, 9))
print(max(3, 4, 6, 7,2, 6, 5, 6, 9))


