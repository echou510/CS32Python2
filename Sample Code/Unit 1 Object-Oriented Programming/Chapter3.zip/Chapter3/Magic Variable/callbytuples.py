# regular argument list
def test_args_kwargs(arg1, arg2, arg3):
    print("arg1:", arg1)
    print("arg2:", arg2)
    print("arg3:", arg3)

# augmeted by tuples
def test_args(*args):
    count = 0;
    for i in args:
        print("argument", count,":", i)
        count += 1

# augmeted by dictionary
def test_kwargs(**kwargs):
    for (key, value) in kwargs.items():
        print((key, value))  # printed in tuple format

# call by tuples
args = ("two", 3, 5)
test_args_kwargs(*args)
# call by dictionary: out of order assignment
kwargs = {"arg3": 3, "arg2": "two", "arg1": 5}
test_args_kwargs(**kwargs)
# augmented by tuples
test_args("two", 3, 5)
# augmented by dictionary
test_kwargs(key1= 3, key2="two", key3=5)

