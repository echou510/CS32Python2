from ABC.AbstractOperation import AbstractOperation

class AddOperation(AbstractOperation):
    def execute(self):
        return self.operand_a + self.operand_b
class SubtractOperation(AbstractOperation):
    def execute(self):
        return self.operand_a - self.operand_b
class MultiplyOperation(AbstractOperation):
    def execute(self):
        return self.operand_a * self.operand_b
class DivideOperation(AbstractOperation):
    def execute(self):
        return self.operand_a / self.operand_b

# Using Abstrac Class for polymorphic operations
print("Using Abstrac Class for polymorphic operations")
operation = AddOperation(1, 2)
print("1+2=", operation.execute())
operation = SubtractOperation(8, 2)
print("8-2=", operation.execute())
operation = MultiplyOperation(8, 2)
print("8*2=", operation.execute())
operation = DivideOperation(8, 2)
print("8/x=", operation.execute())


