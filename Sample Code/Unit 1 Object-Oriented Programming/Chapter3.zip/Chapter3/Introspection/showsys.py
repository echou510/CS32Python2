import sys
print(sys.platform)
print(sys.version)
print(sys.maxsize)
print(sys.argv)
print(sys.path)
print(sys.modules)
