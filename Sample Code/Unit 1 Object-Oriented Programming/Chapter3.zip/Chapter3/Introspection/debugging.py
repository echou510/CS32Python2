def tell_me_about(data):
	print(str(data))
	print(" Id:", id(data))
	if isinstance(data, str):
		# Both str and unicode
		# derive from basestring
		print(" Type: instance of string")
	elif hasattr(data, "__class__"):
		print((" Type: instance of %s" % data.__class__.__name__))
	else: print(" Type: unknown type")
	if hasattr(data, "__getitem__"):
		like = []
		if hasattr(data, "extend"):
			like.append("list-like")
		if hasattr(data, "keys"):
			like.append("dict-like")
		if like:
			print(" %s" % ", ".join(like))

tell_me_about({12:14})
class NC(object): pass
nc = NC()
nc_copy = nc
tell_me_about(nc)
tell_me_about(nc_copy)
tell_me_about(NC())

