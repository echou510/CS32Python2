# Inclusion Polymorphism (Subtype)
class InfiniteSeries(object):
    n=0
    def next(self):
        InfiniteSeries.n += 1
        n=InfiniteSeries.n
        return n
        #raise NotImplementedError("next")
class Fibonacci(InfiniteSeries):
	def __init__(self):
		self.n1, self.n2 = 1, 1
	def next(self):
		n = self.n1
		self.n1, self.n2 = self.n2, self.n1 + self.n2
		return n
class Geometric(InfiniteSeries):
	def __init__(self, divisor=2.0):
		self.n = 1.0 / divisor
		self.nt = self.n / divisor
		self.divisor = divisor
	def next(self):
		n = self.n
		self.n += self.nt
		self.nt /= self.divisor
		return n

def print_series(s, n=10):
    if (s!=[]):
	    for i in range(n):
		    print("%.4g" % s.next())
	    print()

print("Fibonacci: ")
print_series(Fibonacci())
print("Geometric: ")
print_series(Geometric(3.0))
print("Infinite:  ")
print_series(InfiniteSeries())
