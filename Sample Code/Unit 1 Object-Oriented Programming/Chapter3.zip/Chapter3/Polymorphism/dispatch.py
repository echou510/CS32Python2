def what_is_this(data):
	if isinstance(data, str):
			return "instance of string"
	elif hasattr(data, "__class__"):
			return ("instance of %s" %	data.__class__.__name__)
	raise TypeError("unknown type: %s" % str(data))

class NC(object): pass
class OC: pass
print(what_is_this("Hello"))
print(what_is_this(12))
print(what_is_this([1, 2]))
print(what_is_this({12:14}))
print(what_is_this(NC()))
print(what_is_this(OC()))

