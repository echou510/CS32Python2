a2 = [[0]*10]*20      # declare an 2D array

for i in range(len(a2)):
    for j in range(len(a2[0])):
        a2[i][j] = i+j
        print(a2[i][j])

