import datetime # we will use this for date objects

class Person:
    def __init__(self, name, surname, birthdate, address, telephone, email):
        self.__name = name
        self.__surname = surname
        self.__birthdate = birthdate
        self.__address = address
        self.__telephone = telephone
        self.__email = email

    def age(self):
        if hasattr(self, "_age"):  # hasattr check if the attribute exist).
            return self._age

        today = datetime.date.today()
        age = today.year - self.__birthdate.year
        if today < datetime.date(today.year, self.__birthdate.month, self.__birthdate.day):
            age -= 1
        self._age = age
        return age

    def getName(self):
        return self.__name

    def getSurname(self):
        return self.__surname

    def getBirthdate(self):
        return self.__birthdate

    def getAddress(self):
        return self.__address

    def getTelephone(self):
        return self.__telephone

    def getEmail(self):
        return self.__email

    def setName(self, name):
        self.__name = name

    def setSurname(self, surname):
        self.__surname = surname

    def setBirthdate(self, birthdate):
        self.__birthdate = birthdate

    def setAddress(self, address):
        self.__address = address

    def setTelephone(self, telephone):
        self.__telephone = telephone

    def setEmail(self, email):
        self.__email = email

def main():
    person = Person("Jane", "Doe",
    datetime.date(1992, 3, 12),
    "No. 12 Short Street, Greenville",
    "555 456 0987",
    "jane.doe@example.com"
    )

    # built-in attribute accessor, mutator and checker
    person.setName("Tom")  # mutator
    person.setSurname("Jobns")   # mutator
    person.setBirthdate(datetime.date(1994, 8, 15))
    person.setAddress("1 Byte Street, Los Angeles, CA 90007")
    person.setTelephone("213 000 0000")
    person.setEmail("tom.johns@gmail.com")

    print(person.getName())
    print(person.getSurname())
    print(person.getName())
    print(person.getBirthdate())
    print(person.getAddress())
    print(person.getTelephone())
    print(person.getEmail())
    print(person.age())
    print(person.__name)    # this will go wrong because it is trying to access a private data field

if __name__ == "__main__":
    main()
