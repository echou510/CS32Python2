class Person:
    def __init__(self, name, surname):
        self.name = name
        self.surname = surname

    @property
    def fullname(self):
        return "%s %s" % (self.name, self.surname)

def main():
    print("@property decorated version 1: ")
    jane = Person("Jane", "Smith")
    print(jane.fullname) # no brackets!

if __name__ == "__main__":
    main()

