# make a private variable accessible by setter, getter
# and, allow = and right hand-side value to work.

class Foo():
    def __init__(self):
        self.__a = 0

    @property
    def a(self):
        return self.__a

    @a.setter
    def a(self, i):
        self.__a = i


f = Foo()
print(f.a)
f.a = 3
print(f.a)


class Foo2():
    def __init__(self):
        self.a = 0

    def get(self):
        return self.a

    def set(self, i):
        self.a = i

f2 = Foo2()
f2.a = 3
print(f2.a)
print(f2.get())