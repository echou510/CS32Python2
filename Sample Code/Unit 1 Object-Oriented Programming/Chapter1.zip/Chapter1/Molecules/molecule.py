from atom import *   #using in C++, or import in Java

class molecule:
	def __init__(self,name='Generic'):
		self.name = name
		self.atomlist = []
	def addatom(self,atom):
		self.atomlist.append(atom)
	def __repr__(self):
		str = "his is a molecule named %s\n" % self.name
		str = str+"It has %d atoms\n" % len(self.atomlist)
		for atom in self.atomlist:
			str = str + atom.symbol() + " " + atom.__repr__() + '\n'
		return str

def main():
    mol = molecule("Water")
    at = atom(8, 0.0, 0.0, 0.0)
    mol.addatom(at)
    mol.addatom(atom(1, 0.0, 0.0, 1.0))
    mol.addatom(atom(1, 0.0, 1.0, 0.0))
    print(mol)

if __name__ == "__main__":   # public static void main(String[] args) in Java
    main()