d = {1: 'foo', 2: 'bar', 3: 'qux'} 
assert 1 in d 
assert 4 not in d 
assert 'foo' not in d # 'foo' is not a _key_ in the dict
