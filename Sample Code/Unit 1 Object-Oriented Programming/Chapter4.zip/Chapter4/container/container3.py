s = 'foobar'
assert 'b' in s 
assert 'x' not in s 
assert 'foo' in s # a string "contains" all its substrings 