# Generator Expression
numbers = [1, 2, 3, 4, 5, 6]
a = (x*x for x in numbers)
print(next(a))
print(next(a))
print(next(a))
print(next(a))