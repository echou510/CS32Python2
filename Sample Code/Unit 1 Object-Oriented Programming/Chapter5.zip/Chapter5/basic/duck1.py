class Duck:
    def quack(self):
        print("Quack, quack!")
    def fly(self):
        print("Flap, Flap!")

class Goose:
    def quack(self):
        print("Quack!")
    def fly(self):
        print("Flap!")

class Person:
    def quack(self):
        print("I'm Quacking!")
    def fly(self):
        print("I'm Flying!")
# Generic Method: A method handle different object types

def in_the_forest(thing):
    thing.quack()     # both quack() and fly() are polymorphic methods
    thing.fly()

in_the_forest(Duck())
in_the_forest(Goose())
in_the_forest(Person())

