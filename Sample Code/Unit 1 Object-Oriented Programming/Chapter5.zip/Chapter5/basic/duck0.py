# duck0.py
# This example shows a polymorphic method
class Duck:
   def quack(self):
      print('Quack!')
class Goose:
   def quack(self):
      print('Quack')

Goose().quack()    # Goose() create instant temporary object
Duck().quack()     # Duck() create instant temporary object


