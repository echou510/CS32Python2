from math import *

class gaussian:
	def __init__(self,exponent):
		self.exponent = exponent
	def __call__(self,arg):
		return exp(-self.exponent*arg*arg)

def main():
    f = gaussian(3)

    for x in range(-100, 100, 1):
        print(f(x*0.01))

if __name__ == "__main__":
    main()