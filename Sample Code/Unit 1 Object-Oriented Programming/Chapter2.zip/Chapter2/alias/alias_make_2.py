# Create a new <list>
a = [5]

# Create an alias identifier for this list
b = a
print(id(a), id(b))

# Now change the <list> b in-place
b.append(1)

# And observe how this also changes a
# The alias is not broken by in-place operations
print(a, b)
print(id(a), id(b))

