# Create a <list>
a = [5]

# Create a new <list> with the same value
b = list(a)

# We now have two separate variables with identical but separate values
print(a, b)
print(id(a), id(b))

# Same with the full slice technique:
b = a[:]
print(a, b)
print(id(a), id(b))

