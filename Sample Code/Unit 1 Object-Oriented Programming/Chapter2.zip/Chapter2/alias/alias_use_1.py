v_list = [1, 2, 3]

for i in v_list:
    i = i + 1
    print(i)

print(v_list)