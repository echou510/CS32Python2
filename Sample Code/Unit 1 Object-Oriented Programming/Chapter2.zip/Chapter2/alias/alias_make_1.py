# Assign a value to a new variable
a = 5
# Create an alias identifier for this variable
b = a
# Observe how they refer to the same variable!
print(id(a), id(b))
# Create another alias
c = b
# Now assign a new value to b!
b = 3
# And observe how a and c are still the same variable
# But b is not
print(a, b, c)
print(id(a), id(b), id(c))
# Now for another quirk, suppose we do this:
b = a
b = 5
# We used an assignment, but the value didn't actually change
# So the alias remains unbroken
print(id(a), id(b))

