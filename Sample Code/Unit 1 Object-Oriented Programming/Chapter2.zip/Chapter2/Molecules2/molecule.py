from atom import *   #using in C++, or import in Java

class molecule:
	def __init__(self,name='Generic'):
		self.name = name
		self.atomlist = []
	def addatom(self,atom):
		self.atomlist.append(atom)

	def __getitem__(self, index):
		return self.atomlist[index]

	def __repr__(self):
		str = "his is a molecule named %s\n" % self.name
		str = str+"It has %d atoms\n" % len(self.atomlist)
		for atom in self.atomlist:
			str = str + atom.symbol() + " " + atom.__repr__() + '\n'
		return str

	# new methods
	def __setitem__(self, index, value):
		self.atomlist[index]=value

	def __add__(self, other):
		self.atomlist += other

	def __getattr__(self, name):
		pass

	def __del__(self):
		del self

	def __len__(self):
		return len(self.atomlist)

	#def __getslice__(self, low, high):
	#	pass

	def __cmp__(self, other):
		pass

def main():
	mol = molecule("Water")
	at = atom(8, 0.0, 0.0, 0.0)
	mol.addatom(at)
	mol.addatom(atom(1, 0.0, 0.0, 1.0))
	mol.addatom(atom(1, 0.0, 1.0, 0.0))
	print("Print Molecule")
	print(mol)
	print("Print atom in mol list")
	for _atom in mol:
		print(_atom)
	print("Print atoms after translation in mol list")
	mol[0].translate(1.0, 1.0, 1.0)
	print(mol)


if __name__ == "__main__":   # public static void main(String[] args) in Java
    main()