# Atomic Table
Atno_to_Symbol=["", \
"H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", \
"Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca", \
"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", \
"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", \
"Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", \
"Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", \
"Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", \
"Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", \
"Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", \
"Pa", "U", "Np", "Pu","Am", "Cm", "Bk", "Cf", "Es", "Fm", \
"Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", \
"Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"]

class atom:
	def __init__(self, atno, x, y, z):  # constructor
		self.atno = atno
		self.__position = (x,y,z)

	def getposition(self):
		return self.__position

	def setposition(self, x, y, z):
		self.__position = (x, y, z)  # typecheck first!

	def translate(self, x, y, z):
		x0, y0, z0 = self.__position
		self.__position = (x0 + x, y0 + y, z0 + z)

	def symbol(self):                   # a class method
		return Atno_to_Symbol[self.atno]
	def __repr__(self): # overloads printing, similar toString() in Java. __str__ is for containers.
		return "%d %10.4f %10.4f %10.4f" % (self.atno, self.__position[0], self.__position[1], self.__position[2])
        # This return value is in String format like C, Java "Format Specifier %d%s" % data

def main():
    at = atom(6, 0.0, 1.0, 2.0)
    print(at)
    print(at.symbol())

if __name__ == "__main__":
    main()