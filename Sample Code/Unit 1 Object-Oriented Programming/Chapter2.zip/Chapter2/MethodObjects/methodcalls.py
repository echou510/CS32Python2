class A:
    def f(self):
        print("f functional call")

print("Instance call")
x = A()
x.f()
print()
# use method as variable, ceating functional alias
print("Functional alias call")
Xf = x.f
Xf()
print()
# calling instance method in class method way
print("Class method call")
A.f(x)
print()


