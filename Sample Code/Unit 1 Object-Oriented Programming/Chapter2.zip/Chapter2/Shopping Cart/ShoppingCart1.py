class ShoppingCart:
    """Our simple ShoppingCart model"""
    def __init__(self, _items):
        self.items = _items

def main():
    items = ['Item1', 'Item2', 'Item3']
    my_cart = ShoppingCart(items)
    print(my_cart)

if __name__ == "__main__":
    main()