class Employee:  # primitive class as record creator
	pass

john = Employee() # Create an empty employee record
# Fill the fields of the record
john.name = 'John Doe'
john.dept = 'computer lab'
john.salary = 1000
print("Name=%s,  Department=%s, Salary:%d" % (john.name, john.dept, john.salary))

