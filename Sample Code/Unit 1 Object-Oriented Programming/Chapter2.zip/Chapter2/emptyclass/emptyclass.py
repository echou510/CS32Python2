class A:
    pass

a1 = A()
a1.name = "Tom"
a1.age  = 13
print(dir(a1))
print(a1)