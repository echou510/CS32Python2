from math import *
class complex:
    numOfComplex = 0       # like static int cumOfComplex in Java
    def __init__(self, r, i):
        self.real = r                  # like instance variable without static
        self.img  = i
        complex.numOfComplex += 1      # class variable
    def __str__(self):    # like toString()
        return "%.2fi+%.2fj" % (self.real, self.img)
    def conjugate(self):
        return complex(self.real, -1*self.img)
    def absolute(self):
        return sqrt(self.real**2+self.img**2)
    def __abs__(self):
        return sqrt(self.real**2+self.img**2)

    def __add__(self, other):  # overloaing for addition
        if (type(other) == complex):
            return complex(self.real + other.real, self.img + other.img)
        else:
            return complex(self.real + other, self.img)
    def __radd__(self, other):
        if (type(other) == complex):
            return complex(self.real + other.real, self.img + other.img)
        else:
            return complex(self.real + other, self.img)

    def __sub__(self, other):                  #overloaing for addition
        if (type(other)==complex):
            return complex(self.real-other.real, self.img-other.img)
        else:
            return complex(self.real-other, self.img)
    def __rsub__(self, other):
        if (type(other)==complex):
            return complex(-self.real+other.real, -self.img+other.img)
        else:
            return complex(-self.real+other, -self.img)
    def __eq__(self, other):
        return self.real==other.real and self.img == other.img


c1 = complex(3, 4)
print(c1)
print(complex.numOfComplex)

c2 = complex(5, 12)
print(c2)
print(complex.numOfComplex)

print(c1.conjugate())
print(c2.absolute())
print(abs(c2))   # abs is a built-in function

print(c1+c2)
print(c1+3)
print(3+c1)

print(c1-c2)
print(c1-3)
print(3-c1)

print(c1==c2)