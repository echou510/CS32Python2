from tkinter import *

main = Tk()                                  # main is a GUI application or window, sometimes use root

def handler(event):                          # define a handler
    print("clicked at",event.x, event.y)

frame = Frame(main, width=300, height=300)   # frame is a container on main window
main.bind("<Button-1>", handler)             # main.bind or frame.bind both work but bind to different widget
frame.pack()
main.mainloop()

