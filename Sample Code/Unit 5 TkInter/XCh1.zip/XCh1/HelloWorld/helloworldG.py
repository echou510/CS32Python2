from tkinter import *
w=Label(text="Hello, World!")
w.pack()
w.mainloop()