from tkinter import *

class Application(Toplevel):
    def __init__(self):
        super().__init__()
        self.title("Title")     # set title for the window
        self.master.title("Win")
        self.lb = Label(self, text="Label")
        self.lb.place(x=30, y=30)
        #self.pack(fill=BOTH, expand=1)# Toplevel has no pack

def main():
    win = Tk()                         # create a window application
    win.geometry("300x200+100+100")    # setting window geometry
    app = Application()                # start the frame inside the window
    win.mainloop()                     # window go into event loop

if __name__ == "__main__":
    main()



