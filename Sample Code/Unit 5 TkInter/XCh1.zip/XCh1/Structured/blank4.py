from math import *
from tkinter import *

class circle:
    NoOfCircle =0
    def __init__(self, r=1.0):
        self.__r = r
    def getR(self):
        return self.__r
    def getArea(self):
        return pi * self.__r**2

class Application(Frame):                    # master frame
    def __init__(self, owner):
        super().__init__(owner)
        self.initModel()
        self.initUI()
        self.showData()

    def initModel(self):
        self.c1 = circle(2.0)
        self.a = self.c1.getArea()     # need to be frame instance variable to be shown on GUI
        self.c2 = circle(3.0)
        self.b = self.c2.getArea()

    def initUI(self):
        self.master.title("Fream 1")
        self.pack(fill=BOTH, expand=1)

    def showData(self):
        self.lba = Label(self, text=("Circle 1 r=%f area=%f" % (self.c1.getR(), self.a)))
        self.lba.place(x=30, y=30)
        self.lbb = Label(self, text=("Circle 2 r=%f area=%f" % (self.c2.getR(), self.b)))
        self.lbb.place(x=30, y=60)

def main():
    win = Tk()                         # create a window application
    win.geometry("400x150+100+100")    # setting window geometry
    app = Application(win)                     # start the frame inside the window
    win.mainloop()                     # window go into event loop

if __name__ == "__main__":
    main()

