from tkinter import *
class Frame1(Frame):                    # master frame
    def __init__(self, owner):
        super().__init__(owner)
        self.initUI()
    def initUI(self):
        self.master.title("Fream 1")
        self.pack(fill=BOTH, expand=1)
        self.lb = Label(self, text="Master")
        self.lb.place(x=30, y=30)

class Frame2(Toplevel):                 # slave frame
    def __init__(self, owner):
        super().__init__(owner)
        self.initUI()
    def initUI(self):
        self.title("Frame 2")
        self.lb = Label(self, text="Slave")
        self.lb.place(x=30, y=30)

def main():
    win = Tk()                         # create a window application
    win.geometry("300x200+100+100")    # setting window geometry
    app = Frame1(win)                     # start the frame inside the window
    app2 = Frame2(win)                      # start the frame inside the window
    win.mainloop()                     # window go into event loop

if __name__ == "__main__":
    main()

