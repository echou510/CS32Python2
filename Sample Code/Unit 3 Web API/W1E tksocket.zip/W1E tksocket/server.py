import socket,os
from tkinter import *
from tkinter import filedialog, messagebox

def startServer(portName,ip):
    if portName != '' and ip != '':
        messagebox.showinfo('Server Started','Server running!!! ok will be enabled after transfer')
        port = int(portName)
        ipName = ip
        sd = socket.socket()
        sd.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)   #reuse socket
        sd.bind((ipName, port))
        sd.listen(50)

        con, addr = sd.accept()
        print(' connection from ' + str(addr))
        con.send(messagebox.showinfo('connected', 'Connection Successful'))

        while True:

            con.send(str(filedialog.askopenfilename(initialdir='~', title='Choose a text file/program')))
            fileN = con.recv(1024)

            if os.path.isfile(fileN):

                con.send(messagebox.showinfo('Process completed', 'Rerun server to transfer again'))
                con.send('exists')
                fileN = str(fileN)


                #read contents

                fd = open(fileN, 'r')
                buff = fd.read()
                print(buff)
                print(len(buff))
                fd.close()

                #send contents
                con.send(str(len(buff)-1))
                print(con.recv(14))    #acknowledgement of length received
                con.send(buff)
                break
            else:
                con.send(messagebox.showerror('Failed', 'Select appropriate file'))
                con.send('ne')
        sd.close()
    else:
        messagebox.showerror('Failed','Failed to start server. Give appropriate inputs')

def main():
    root = Tk()
    root.geometry('300x200')
    root.title('Server')

    ipLabel = Label(root,text='\nEnter IP Address of server\n')
    portLabel = Label(root, text='\nEnter Port Address of server\n')

    ipEntry = Entry(root)
    portEntry = Entry(root)

    connectButton = Button(root, text='Run',command=lambda: startServer(portEntry.get(), ipEntry.get()))

    ipLabel.pack()
    ipEntry.pack()
    portLabel.pack()
    portEntry.pack()
    connectButton.pack()

    root.mainloop()

main()