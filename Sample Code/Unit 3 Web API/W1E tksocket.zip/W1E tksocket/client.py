import socket
from tkinter import *
from tkinter import messagebox

def establishConnection(ipEntry,portEntry,root):
    if ipEntry != '' and portEntry != '':
        port = int(portEntry)
        ipName = str(ipEntry)

        sd = socket.socket()
        sd.connect((ipName, port))
        # ack if connection established
        sd.recv(1024)

        while True:
            #file select dialog
            fileN = sd.recv(1024)
            sd.send(fileN)          #send file name to open

            sd.recv(1024)           #dialog after file selected or not
            fileAck = sd.recv(6)    #acknowledge if file correct

            if fileAck == 'exists':
                leng = int(sd.recv(10))
                sd.send('length recieved')
                buff = str(sd.recv(leng))

                saveLabel = Label(root, text='\n\nSave with Name\n')
                saveNameEntry = Entry(root)
                saveButton = Button(root, text='SAVE', command=lambda: saveFile(saveNameEntry.get(), buff, root))
                saveLabel.pack()
                saveNameEntry.pack()
                saveButton.pack()
                break
        sd.close()

def saveFile(fileN, buff, root):
    fd = open(fileN, 'w')
    fd.write(buff)
    fd.close()
    messagebox.showinfo('Operation Complete','file saved as '+fileN)
    root.destroy()

def main():
    root = Tk()
    root.geometry('300x600')
    root.title('Client')

    ipLabel = Label(root,text='\nEnter IP Address of server\n')
    portLabel = Label(root, text='\nEnter Port Address of server\n')

    ipEntry = Entry(root)
    portEntry = Entry(root)

    connectButton = Button(root, text='Connect', command=lambda: establishConnection(ipEntry.get(), portEntry.get(),root))

    ipLabel.pack()
    ipEntry.pack()
    portLabel.pack()
    portEntry.pack()
    connectButton.pack()

    root.mainloop()

main()