import json

fp = open("person.json", "r")
str = fp.read()
person = json.loads(str)

print("Name=", person['name'])
print("Score=", person['score'])

friends = person['friends']
for i in range(len(person['friends'])):
    print("Friend[%d]=%s" % (i, friends[i]))

person['name'] = "Mr."+person['name']
person['score'] = person['score'] -5

str_out = json.dumps(person)
fout = open("person_out.json", "w")
fout.write(str_out)

fp.close()
fout.close()

