# convert from Python dictionary to Json string
import json
d = {
    'first_name': 'Guido',
    'second_name': 'Rossum',
    'titles': ['BDFL', 'Developer'],
}
print(json.dumps(d))

