import urllib.request
import urllib.parse
from contextlib import closing

values = {'q':"HTTP"}   # dictionary format
data = urllib.parse.urlencode(values)
cgi = "https://www.google.com/search"
url = cgi + "?" + data

request = urllib.request.Request(url) # make request to google.com
request.add_header('User-Agent', "Mozilla/5.0 Chrome/41.0.2227.0 Safari/537.36")
response = urllib.request.urlopen(request)             # receive response from google.com
response_data = response.read()

print(response_data.decode('utf8'))
response.close()



