import urllib.request
import urllib.parse
import codecs

MY_YOUTUBE_API_KEY = "AIzaSyBhfd8gXgkfwHO9Gs8cPEa2Cw9Jc3av2MU"
# prepare API request
data = {}
data['key']  = MY_YOUTUBE_API_KEY
data['type'] = 'video'
data['part'] = 'snippet'
data['maxResults'] = '10'
data['q'] = 'lakers clippers'
data_query = urllib.parse.urlencode(data)
url = "https://www.googleapis.com/youtube/v3/search?"
url_query = url+data_query

# headers needed to pass the web-site auto-bot check.
headers = {}
headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686)"  # server type at google

# make API request
request = urllib.request.Request(url_query, headers=headers) # make request to google.com
response = urllib.request.urlopen(request)   # just like open a file
response_data = response.read()
response_text = response_data.decode("utf8")  # convert bytes to utf8

# convert text to a html file
lines = response_text.splitlines()
fp = codecs.open("lakers.json", "w", "utf8")   # open a file for utf-8 text format
for line in lines:
    fp.write(line+"\n")
fp.close()
response.close()

