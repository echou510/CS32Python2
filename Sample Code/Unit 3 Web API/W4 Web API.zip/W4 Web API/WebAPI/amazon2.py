import urllib.request
import urllib.parse
import codecs

# prepare API request
query_parameters_strings = {'url':'search-alias%3Daps', 'field-keywords':'u2 the joshua tree'}
query_parameters = urllib.parse.urlencode(query_parameters_strings)
url = "https://www.amazon.com/s/ref=nb_sb_noss_2/183-7159112-3775704?"
url_query = url+query_parameters

# headers needed to pass the web-site auto-bot check.
headers = {}
headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686)"  # server type at google

# make API request
request = urllib.request.Request(url_query, headers=headers) # make request to google.com
response = urllib.request.urlopen(request)   # just like open a file
response_data = response.read()
response_text = response_data.decode("utf8")  # convert bytes to utf8

# convert text to a html file
lines = response_text.splitlines()
fp = codecs.open("joshua_tree2.html", "w", "utf8")   # open a file for utf-8 text format
for line in lines:
    fp.write(line+"\n")
fp.close()
response.close()




