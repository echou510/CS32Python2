from urllib.request import *
req = urlopen("http://www.google.com")   # just like open a file
print(req.read())  # in encoded 'utf8 format'
req.close()



