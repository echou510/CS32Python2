from urllib.request import *
response = urlopen("http://www.ics.uci.edu/~thornton/ics32/Notes/ExceptionsAndFiles/oops.py")   # just like open a file
r = response.read()
st = r.decode("utf8")
print(st)
response.close()


