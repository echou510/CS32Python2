import urllib.request
import urllib.parse

values = {'q':"HTTP"}   # dictionary format
data = urllib.parse.urlencode(values)
url = "https://www.google.com/search?"+data # resource (the google search engine)
# same as url = "https://www.google.com/search?q=HTTP"

headers = {}
headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686)"  # server type at google

request = urllib.request.Request(url, headers=headers) # make request to google.com
response = urllib.request.urlopen(request)             # receive response from google.com
response_data = response.read()

print(response_data.decode('utf8'))
response.close()



