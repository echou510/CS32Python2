# Standalong project for Connect 4
1. run play.py to play this Connect 4 program. 
2. coonectfour.py is the gameboard module
3. connectfour_mini.py is only a stripped down version. 