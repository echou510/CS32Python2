dicx = [
    {"a":3, "b":4, "d":5},
    {"a":1, "b":3, "d":0},
    {"a":2, "b":4, "d":9},
    {"a":5, "b":6, "d":8}
]

x = []
for dic in dicx:
    kk = dic.key()
    for key in kk:
        x.append(dicx[key])

print(x)