from socket import *
s = socket(AF_INET,SOCK_STREAM)
s.connect(("www.python.org",80))
message = "GET / index.html HTTP/1.0\\n\\n"
#message = message.encode('utf-8')
s.send(bytes(message, 'utf8'))
chunks = []
while True:
    chunk = s.recv(16384)
    if not chunk: break
    chunks.append(chunk)
s.close()
response = "".join(chunks)
print(response)

