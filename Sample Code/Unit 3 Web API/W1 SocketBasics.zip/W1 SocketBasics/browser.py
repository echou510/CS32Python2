# starting a server (socket-bind-listen)
from socket import *
print("Server side starts ...")

# step 1 make a connection
s = socket(AF_INET, SOCK_STREAM)
s.bind(("",15000))
s.listen(5)
c,a = s.accept()
request = c.recv(8192)
print(request)
c.send(bytes("HTTP/1.0 200 OK\r\n", 'utf8'))
c.send(bytes("Content-type: text/html\r\n",'utf8'))
c.send(bytes("\r\n",'utf8'))
c.send(bytes("<h1>Hello World!</h1>",'utf8'))
c.close()
s.close()

