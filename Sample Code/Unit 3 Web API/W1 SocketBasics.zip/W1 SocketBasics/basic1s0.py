# starting a server (socket-bind-listen)
from socket import *
print("Server side starts ...")

# step 1 make a connection
s = socket(AF_INET, SOCK_STREAM)
s.bind(("",15000))
s.listen(5)
c,a = s.accept()
# checking
print(c)
print(a)
# step 2  receiving some data and send back
data = c.recv(1024)
print(data)
# send back
c.send(bytes("Hello Yourself", 'utf8'))
# Step 3
c.send(bytes("Goodbye", 'utf8'))
c.close()
s.close()



