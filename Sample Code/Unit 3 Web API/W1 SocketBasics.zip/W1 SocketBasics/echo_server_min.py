from socket import *

def read_host() -> str:
    while True:
        host = input('Host: ').strip()
        if host == '':
            print('Please specify a host (either a name or an IP address)')
        else:
            return host

def read_port() -> int:
    while True:
        try:
            port = int(input('Port: ').strip())
            if port < 0 or port > 65535:
                print('Ports must be an integer between 0 and 65535')
            else:
                return port
        except ValueError:
            print('Ports must be an integer between 0 and 65535')

def server(host, port):
    s = socket(AF_INET, SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print("Waiting for client...")
    c, a = s.accept()
    ci = c.makefile('r')
    co = c.makefile('w')
    return c, ci, co, a, s

def read_message() -> str:
    return input('Server Message: ')

def send_message(con: 'connection', m: str) -> None:
    s, si, so = con
    so.write(m + '\r\n')
    so.flush()

def receive_response(con: 'connection') -> None:
    s, si, so = con
    return si.readline()[:-1]
def print_response(resp: str) -> None:
    print('Client Response: ' + resp)

def user_interface() -> None:
    host = read_host()
    port = read_port()
    print('Start server at {} (port {})...'.format(host, port))
    c, ci, co, a, s = server(host, port)
    con = c, ci, co
    print('Connected at {}:{}!', a[0], a[1])
    print("Wait for Client to say hello!")
    resp = receive_response(con)
    print_response(resp)
    while True:
        m = read_message()
        if m == '':
            break
        else:
            send_message(con, m)
            resp = receive_response(con)
            print_response(resp)
    print('Closing connection...')
    s.close()
    print('Closed!')

if __name__ == '__main__':
    user_interface()
