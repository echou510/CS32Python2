# starting a client (socket, connect)
from socket import *
print("Client side starts...")
# step 1 make a connection
s = socket(AF_INET, SOCK_STREAM)
s.connect(("localhost",15000))
# step 2 send some data
s.send(bytes("Hello", 'utf8'))   # client (here) send to server
# receive
resp = s.recv(1024)
print(resp)
# step 3 closing the connection
s.recv(1024)

