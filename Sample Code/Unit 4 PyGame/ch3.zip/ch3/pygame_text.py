import pygame
from pygame_color_simple import *

class Label:
    def __init__(self, surface, myfont, color, position, message):
        self.surface = surface
        self.myfont = myfont
        self.color = color
        self.position = position
        self.message = message
        self.box = None
    def draw(self):
        self.label = self.myfont.render(self.message, 1, self.color)
        self.surface.blit(self.label, self.position)
        self.box = self.label.get_rect()
    def getBox(self):
        return self.box
    def getMessage(self):
        return self.message
    def clear(self):
        pygame.draw.rect(self.surface, black,  \
                            (self.box.left+self.position[0], \
                            self.box.top+self.position[1],  \
                            self.box.width,  \
                            self.box.height) \
                         )

class Button(Label):
    def __init__(self, surface, myfont, fore_ground, back_ground, position, message, padding_x=4, padding_y=4, width=0, height=0):
        super().__init__(surface, myfont, fore_ground, position, message)
        super().draw()
        self.buttonBox = self.box.inflate(padding_x, padding_y)
        self.buttonBox.centerx = position[0]+self.box.centerx
        self.buttonBox.centery = position[1]+self.box.centery
        self.fore_ground = fore_ground
        self.back_ground = back_ground

    def draw(self):
        self.surface.fill(self.back_ground, self.buttonBox)
        self.surface.blit(self.label, self.position)

    def getBox(self):
        return self.buttonBox

    def connect(self, func):
        self.func = func

    def onClick(self):
        self.func()

class InputBox:
    def __init__(self, FONT, COLOR_ACTIVE, COLOR_INACTIVE, x, y, w, h, padding_x=0, padding_y=0, text=''):
        self.rect = pygame.Rect(x+padding_x, y+padding_y, w+padding_x*2, h+padding_y*2)
        self.color = COLOR_INACTIVE
        self.text = text
        self.txt_surface = FONT.render(text, True, self.color)
        self.active = False
        self.font = FONT
        self.color_active = COLOR_ACTIVE
        self.color_inactive = COLOR_INACTIVE
        self.padding_x = padding_x
        self.padding_y = padding_y
        self.result = None

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            # If the user clicked on the input_box rect.
            if self.rect.collidepoint(event.pos):
                # Toggle the active variable.
                self.active = not self.active
            else:
                self.active = False
            # Change the current color of the input box.
            self.color = self.color_active if self.active else self.color_inactive
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:
                    #print(self.text)
                    self.result = self.text
                    self.text = ''
                elif event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode
                # Re-render the text.
                self.txt_surface = self.font.render(self.text, True, self.color)

    def getText(self):   # None if no return, string if has returned string
        return self.result

    def reset(self):
        self.result = None

    def update(self):
        # Resize the box if the text is too long.
        width = max(200, self.txt_surface.get_width()+10)
        self.rect.w = width

    def draw(self, screen):
        # Blit the text.
        screen.blit(self.txt_surface, (self.rect.x+self.padding_x, self.rect.y+self.padding_y))
        # Blit the rect.
        pygame.draw.rect(screen, self.color, self.rect, 2)




