import pygame
import sys

width, height = 240, 480

def main():
    pygame.init()
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption('Hello World!')

    texton = True
    myfont = pygame.font.SysFont("Calibri", 24, True, False)
    for i in range(20):
        if (texton):
            label = myfont.render("Hello World!", 1, (255, 255, 0))
            root.blit(label, (50, 100))
            texton = False
        else:
            pygame.draw.rect(root, (0, 0, 0), ((0, 0, 240, 480)))
            texton = True
        pygame.display.update()
        pygame.time.delay(200)

if __name__ == "__main__":
    main()


