import sys
import pygame
import random

row, col = 12, 6                       # number of rows and column
block_size = 60                        # block size
zero = (block_size/2, block_size/2)    # first block's center point
wing = block_size/2 - 2                # half the length of a block side
width, height = col*block_size, row*block_size

cycle_time = 300
delay = 50

color = {'BLACK': (0, 0, 0),
         'WHITE': (255, 255, 255),
         'RED':   (255, 0, 0),
         'ORANGE':(255, 128, 0),
         'YELLOW':(255, 255, 0),
         'APPLE':(128, 255, 0),
         'GREEN':(0, 255, 0),
         'LAKE':(0, 255, 128),
         'CYAN':(0, 255, 255),
         'TEAL':(0, 128, 255),
         'PURPLE':(128, 0, 255),
         'MAGENTA':(255, 0, 255),
         'DEEPPINK':(255, 0, 128)
         }

# color_code list: quick access to the right color.
color_code = [color['RED'], color['ORANGE'], color['YELLOW'], color['APPLE'], color['GREEN'],
              color['LAKE'], color['CYAN'], color['TEAL'], color['PURPLE'], color['MAGENTA'], color['BLACK']]

def draw_block(root, i, j, color):
    global wing
    pygame.draw.rect(root, color, ((zero[0]-wing+j*60), (zero[1]-wing+i*60), wing*2, wing*2))

def clear_block(root, i, j):
    global color, wing
    draw_block(root, i, j, color['BLACK'], wing)

def main():
    global color_code, wing, cycle_time, delay, row, col, color
    pygame.init()
    root = pygame.display.set_mode((width, height))
    root.fill(color['BLACK'])
    pygame.display.set_caption('Hello World!')
    #draw_block(root, 0, 0, color_code[0], wing)

    while True:
        for event in pygame.event.get((pygame.KEYDOWN, pygame.KEYUP, pygame.QUIT)):
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    cycle_time = delay
                    continue
                elif event.key == pygame.K_SPACE:
                    i = random.randint(0, row-1)  # random row
                    j = random.randint(0, col-1)  # random column
                    k = random.randint(0, 9)      # random color
                    draw_block(root, i, j, color_code[k])
                    print("space")
                    pygame.time.delay(delay)
                    continue
                elif event.key == pygame.K_p:
                    for i in range(row):         # clear all all rows and all columns
                        for j in range(col):
                            draw_block(root, i, j)
                    print("p key")
                    pygame.time.delay(delay)
                    continue
            elif event.type == pygame.KEYUP:
                if cycle_time != 300: cycle_time = 300

        pygame.display.update()
        pygame.time.delay(cycle_time)

if __name__ == "__main__":
    main()
