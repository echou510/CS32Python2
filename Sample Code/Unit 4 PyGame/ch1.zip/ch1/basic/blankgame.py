import pygame
import sys

width, height = 240, 480

def main():
    pygame.init()
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption('Hello World!')
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.update()

if __name__ == "__main__":
    main()

