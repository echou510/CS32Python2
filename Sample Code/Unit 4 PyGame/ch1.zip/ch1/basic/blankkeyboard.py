import sys
import pygame

width, height = 240, 480
cycle_time = 300
delay = 50
# game data
count = 0

def data_init():
    global count
    count = 0

def main():
    global width, height, cycle_time, delay, count
    # initialize game board and other data
    data_init()
    pygame.init()
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption('Hello World!')
    while True:
        for event in pygame.event.get((pygame.KEYDOWN, pygame.KEYUP, pygame.QUIT)):
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    cycle_time = delay
                    continue
                elif event.key == pygame.K_SPACE:
                    # rotate faller
                    print("rotate")
                    pygame.time.delay(delay)
                    continue
                elif event.key == pygame.K_RIGHT:
                    # move faller right
                    print("Right>")
                    pygame.time.delay(delay)
                    continue
                elif event.key == pygame.K_LEFT:
                    # move faller left
                    print("Left<")
                    pygame.time.delay(delay)
                    continue
            elif event.type == pygame.KEYUP:
                if cycle_time != 300: cycle_time = 300

        pygame.display.update()
        pygame.time.delay(cycle_time)
        count = count + 1
        print(count)

if __name__ == "__main__":
    main()