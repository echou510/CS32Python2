import pygame

pygame.mixer.init()
sound = pygame.mixer.Sound("beeps.wav")
pygame.mixer.Sound.play(sound)
pygame.time.wait(int(sound.get_length() * 1000))