import pygame

pygame.mixer.init()
sounda = pygame.mixer.Sound('beeps.wav')
sounda.play()
pygame.time.wait(int(sounda.get_length() * 1000))
