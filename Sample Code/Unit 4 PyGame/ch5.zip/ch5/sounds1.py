import pygame
pygame.init()

pygame.mixer.init()
sounda = pygame.mixer.Sound('beeps.wav')
sounda.play()

while pygame.mixer.get_busy():
    pygame.time.delay(10)
    pygame.event.poll()