import pygame, sys
width, height = 240, 480
cycle_time = 200

def draw_message(surface, myfont, color, position, message):
    label = myfont.render(message, 1, color)
    surface.blit(label, position)
    return label.get_rect()

def clear_block(surface, x, y, w, h):
    pygame.draw.rect(surface, (0, 0, 0), (x, y, w, h))

def clear_window(surface):
    global width, height
    clear_block(surface, 0, 0, width, height)

def drawWindow(title):
    pygame.init()
    pygame.font.init()  # initialize the font module
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption(title)
    myfont = pygame.font.SysFont("Calibri", 36, True, False)
    texton = True
    label_rect = 0
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.font.quit()  # unitialize the font module
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if (texton):
                        label_rect = draw_message(root, myfont, (255, 255, 0), (20, 100), "Hello World!")
                        print(label_rect.left)
                        print(label_rect.top)
                        print(label_rect.width)
                        print(label_rect.height)
                        texton = not texton
                    else:
                        clear_block(root, label_rect.left+20, label_rect.top+100, label_rect.width, label_rect.height)
                        texton = not texton
                    continue
        pygame.time.delay(cycle_time)
        pygame.display.update()
    pygame.font.quit()  # unitialize the font module
    pygame.quit()


if __name__ == "__main__":
    drawWindow("Display and Clear 2")