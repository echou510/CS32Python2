import pygame, sys
from pygame_text import *
width, height = 240, 480
cycle_time = 200

def clear_block(surface, x, y, w, h):
    pygame.draw.rect(surface, (0, 0, 0), (x, y, w, h))

def clear_window(surface):
    global width, height
    clear_block(surface, 0, 0, width, height)

def drawWindow(title):
    pygame.init()
    pygame.font.init()  # initialize the font module
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption(title)
    myfont = pygame.font.SysFont("Calibri", 36, True, False)
    textonA= True
    textonB= True
    labelA = Label(root, myfont, (255, 255, 0), (20, 100), "Start Label")
    labelB = Label(root, myfont, (255, 128, 128), (20, 200), "Lower Label")
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.font.quit()  # unitialize the font module
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if (textonA):
                        labelA.draw()
                        textonA = not textonA
                    else:
                        labelA.clear()
                        textonA = not textonA
                    continue
                elif event.key == pygame.K_b:
                    if (textonB):
                        labelB.draw()
                        textonB = not textonB
                    else:
                        labelB.clear()
                        textonB = not textonB
                    continue
        pygame.time.delay(cycle_time)
        pygame.display.update()
    pygame.font.quit()  # unitialize the font module
    pygame.quit()

if __name__ == "__main__":
    drawWindow("Display and Clear 3")
