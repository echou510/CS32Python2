import pygame, sys
width, height = 240, 480
cycle_time    = 200

def draw_message(surface, myfont, color, position, message):
    label = myfont.render(message, 1, color)
    surface.blit(label, position)

def drawWindow(title):
    pygame.init()
    pygame.font.init()  # initialize the font module
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption(title)
    myfont = pygame.font.SysFont("Calibri", 36, True, False)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.font.quit()   #unitialize the font module
                pygame.quit()
                sys.exit()
        draw_message(root, myfont, (255, 255, 0), (20, 100), "Hello World!")
        pygame.time.delay(cycle_time)
        pygame.display.update()
    pygame.font.quit()   #unitialize the font module
    pygame.quit()

if __name__ == "__main__":
    drawWindow("Simple Font Demo")