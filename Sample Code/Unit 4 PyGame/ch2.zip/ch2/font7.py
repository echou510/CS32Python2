import pygame, sys
import pygame_color_simple as colors
from pygame_text import *
width, height = 640, 480
cycle_time = 100

def move_label(root, myfont, color, label, x, y, vertical=True, loop=True):
    global height
    label.clear()
    if (vertical):
        if (not loop): y = y + 5
        else: y = (y+5) % height
    else:
        if (not loop): x = x + 5
        else: x = (x+5) % width
    label = Label(root, myfont, color, (x, y), label.getMessage())
    label.draw()
    return (label, x, y)

def clear_block(surface, x, y, w, h):
    pygame.draw.rect(surface, colors.black, (x, y, w, h))

def clear_window(surface):
    global width, height
    clear_block(surface, 0, 0, width, height)

def quit_game():
    pygame.font.quit()  # unitialize the font module
    pygame.quit()
    sys.exit()

def drawWindow(title):
    pygame.init()
    pygame.font.init()  # initialize the font module
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption(title)
    myfont  = pygame.font.SysFont("Calibri", 36, True, False)
    myfont2 = pygame.font.SysFont("Calibri", 24, True, False)
    x1 = 20
    y1 = 100
    x2 = 20
    y2 = 200
    x3 = 570
    y3 = 15
    c1 = colors.yellow
    c2 = colors.uci_blue
    c3 = colors.gray
    c4 = colors.black
    labelA  = Label(root, myfont, c1, (x1, y1), "Moving")
    labelB  = Label(root, myfont, c2, (x2, y2), "Label")
    buttonA = Button(root, myfont2, c4, c3, (x3, y3), "Quit", 30, 6)
    buttonA.connect(quit_game)
    buttonA.draw()      # default button
    moving = False
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    moving = True
                    continue
            elif (event.type == pygame.MOUSEBUTTONDOWN and buttonA.getBox().collidepoint(event.pos)):
                buttonA.onClick()

        if (not moving):
            labelA.draw()
            labelB.draw()
        else:
            (labelA, x1, y1) = move_label(root, myfont, c1, labelA, x1, y1, True, True)
            (labelB, x2, y2) = move_label(root, myfont, c2, labelB, x2, y2, False, True)

        pygame.time.delay(cycle_time)
        pygame.display.update()
    pygame.font.quit()  # unitialize the font module
    pygame.quit()

if __name__ == "__main__":
    drawWindow("Button")