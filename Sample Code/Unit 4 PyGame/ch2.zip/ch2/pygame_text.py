import pygame
from pygame_color_simple import *

class Label:
    def __init__(self, surface, myfont, color, position, message):
        self.surface = surface
        self.myfont = myfont
        self.color = color
        self.position = position
        self.message = message
        self.box = None
    def draw(self):
        self.label = self.myfont.render(self.message, 1, self.color)
        self.surface.blit(self.label, self.position)
        self.box = self.label.get_rect()
    def getBox(self):
        return self.box
    def getMessage(self):
        return self.message
    def clear(self):
        pygame.draw.rect(self.surface, black,  \
                            (self.box.left+self.position[0], \
                            self.box.top+self.position[1],  \
                            self.box.width,  \
                            self.box.height) \
                         )

class Button(Label):
    def __init__(self, surface, myfont, fore_ground, back_ground, position, message, padding_x=4, padding_y=4, width=0, height=0):
        super().__init__(surface, myfont, fore_ground, position, message)
        super().draw()
        self.buttonBox = self.box.inflate(padding_x, padding_y)
        self.buttonBox.centerx = position[0]+self.box.centerx
        self.buttonBox.centery = position[1]+self.box.centery
        self.fore_ground = fore_ground
        self.back_ground = back_ground

    def draw(self):
        self.surface.fill(self.back_ground, self.buttonBox)
        self.surface.blit(self.label, self.position)

    def getBox(self):
        return self.buttonBox

    def connect(self, func):
        self.func = func

    def onClick(self):
        self.func()






