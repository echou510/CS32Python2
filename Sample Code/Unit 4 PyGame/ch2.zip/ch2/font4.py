import pygame, sys
from pygame_text import *
width, height = 640, 480
cycle_time = 100

def move_label(root, myfont, color, label, x, y, vertical=True, loop=True):
    global height
    label.clear()
    if (vertical):
        if (not loop): y = y + 5
        else: y = (y+5) % height
    else:
        if (not loop): x = x + 5
        else: x = (x+5) % width
    label = Label(root, myfont, color, (x, y), label.getMessage())
    label.draw()
    return (label, x, y)

def clear_block(surface, x, y, w, h):
    pygame.draw.rect(surface, colors.black, (x, y, w, h))

def clear_window(surface):
    global width, height
    clear_block(surface, 0, 0, width, height)

def drawWindow(title):
    pygame.init()
    pygame.font.init()  # initialize the font module
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption(title)
    myfont = pygame.font.SysFont("Calibri", 36, True, False)
    x = 20
    y = 100
    x1 = 20
    y1 = 200
    c1 = (255, 255, 0)
    c2 = (0, 128, 255)
    labelA = Label(root, myfont, c1, (x, y), "Moving")
    labelB = Label(root, myfont, c2, (x1, y1), "Label")
    moving = False
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.font.quit()  # unitialize the font module
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    moving = True
                    continue

        if (not moving):
            labelA.draw()
            labelB.draw()
        else:
            (labelA, x, y) = move_label(root, myfont, c1, labelA, x, y, True, True)
            (labelB, x1, y1) = move_label(root, myfont, c2, labelB, x1, y1, False, True)

        pygame.time.delay(cycle_time)
        pygame.display.update()
    pygame.font.quit()  # unitialize the font module
    pygame.quit()

if __name__ == "__main__":
    drawWindow("Moving Labels")
