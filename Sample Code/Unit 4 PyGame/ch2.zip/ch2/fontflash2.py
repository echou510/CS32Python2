import pygame
width, height = 240, 480

def main():
    pygame.init()
    pygame.font.init()  # initialize the font module
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption('Hello World!')

    texton = True
    myfont = pygame.font.SysFont("Calibri", 36, True, False)
    for i in range(20):
        if (texton):
            label = myfont.render("Hello World!", 1, (255, 255, 0))
            root.blit(label, (20, 100))
            texton = False
        else:
            pygame.draw.rect(root, (0, 0, 0), ((0, 0, 240, 480)))
            texton = True
        pygame.display.update()
        pygame.time.delay(200)
    pygame.font.quit()   #unitialize the font module
    pygame.quit()

if __name__ == "__main__":
    main()