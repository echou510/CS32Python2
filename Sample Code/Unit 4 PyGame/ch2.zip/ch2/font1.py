import pygame, sys
width, height = 240, 480
cycle_time    = 200

def draw_message(surface, myfont, color, position, message):
    label = myfont.render(message, 1, color)
    surface.blit(label, position)
    
def clear_window(surface):
    global width, height
    pygame.draw.rect(surface, (0, 0, 0), (0, 0, width, height))

def drawWindow(title):
    pygame.init()
    pygame.font.init()  # initialize the font module
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption(title)
    myfont = pygame.font.SysFont("Calibri", 36, True, False)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.font.quit()   #unitialize the font module
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    clear_window(root)
                    continue
                elif event.key == pygame.K_SPACE:
                    draw_message(root, myfont, (255, 255, 0), (20, 100), "Hello World!")
                    continue
        pygame.time.delay(cycle_time)
        pygame.display.update()
    pygame.font.quit()   #unitialize the font module
    pygame.quit()

if __name__ == "__main__":
    drawWindow("Simple Font Demo")