import pygame
def __pygamebox(title, message):
    pygame.quit()  # clean out anything running
    pygame.display.init()
    pygame.font.init()
    root = pygame.display.set_mode((460, 140))
    pygame.display.set_caption(title)
    font = pygame.font.Font(None, 18)
    foreg, backg, liteg = (0, 0, 0), (180, 180, 180), (210, 210, 210)
    ok = font.render('Quit', 1, foreg, liteg)
    okbox = ok.get_rect().inflate(200, 10)
    okbox.centerx = root.get_rect().centerx
    okbox.bottom = root.get_rect().bottom - 10
    root.fill(backg)
    root.fill(liteg, okbox)
    root.blit(ok, okbox.inflate(-200, -10))
    pos = [10, 10]
    for text in message.split('\n'):
        if text:
            msg = font.render(text, 1, foreg, backg)
            root.blit(msg, pos)
        pos[1] += font.get_height()
    pygame.display.flip()
    stopkeys = pygame.K_ESCAPE, pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER
    while 1:
        event = pygame.event.wait()
        if event.type == pygame.QUIT or \
                (event.type == pygame.KEYDOWN and event.key in stopkeys) or \
                (event.type == pygame.MOUSEBUTTONDOWN and okbox.collidepoint(event.pos)):
            break
    pygame.quit()


__pygamebox("Font 1", "Hello! \nHow are you?")
