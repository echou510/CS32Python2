import pygame
import sys

width, height = 240, 480
cycle_time = 300

# game data
count = 0

def data_init():
    global count
    count = 0

def main():
    global width, height, cycle_time, count
    # initialize game board and other data
    data_init()

    pygame.init()
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption('Hello World!')
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.update()
        pygame.time.delay(cycle_time)
        count = count + 1
        print(count)
    pygame.quit()

if __name__ == "__main__":
    main()