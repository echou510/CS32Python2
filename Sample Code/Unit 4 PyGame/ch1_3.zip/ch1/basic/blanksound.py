import pygame
import sys

width, height = 240, 480

def main():
    pygame.init()
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption('Hello World!')
    pygame.mixer.music.load('tada.mp3')
    pygame.mixer.music.play(-1, 0.0)
    pygame.time.delay(1500)
    pygame.mixer.music.stop()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.update()
    pygame.quit()

if __name__ == "__main__":
    main()


