import pygame
import sys

width, height = 240, 480

def main():
    pygame.init()
    root = pygame.display.set_mode((width, height))
    pygame.display.set_caption('Hello World!')
    root.fill(pygame.Color(64, 64, 64))                            # by Color(R, G, B)
    pygame.draw.rect(root, (255, 0, 0), (50, 50, 50, 50))          # by Color tuple
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.update()
    pygame.quit()

if __name__ == "__main__":
    main()

