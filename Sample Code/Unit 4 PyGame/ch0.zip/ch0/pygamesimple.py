# pygameSimple.py
import pygame
#from pygame.locals import *

pygame.init()
screenSize = (640, 480) 
screen = pygame.display.set_mode(screenSize)

screen.fill((255, 255, 255))
pygame.display.set_caption("Hello, World!")

clock = pygame.time.Clock() 

running = True
while running: 
    time_passed = clock.tick(30)
    for event in pygame.event.get(): 
        if event.type == pygame.QUIT: 
            running = False 
    pygame.display.update()
pygame.quit()