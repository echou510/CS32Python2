from flask import Flask, render_template
app = Flask(__name__)   # create Flask as app
app.config['SECRET_KEY'] = 'fdahdfahlfa'
from routes import *    # same effects a the @app.route in app7.py

if __name__ == "__main__": 
    app.run(debug=True)
