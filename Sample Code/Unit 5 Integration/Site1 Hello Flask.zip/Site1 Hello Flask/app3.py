from flask import Flask 
app = Flask(__name__)   # create Flask as app

@app.route("/")   # root directory of the site
def home():       # return HTML template
    return "<h1>Hello Flask</h1>"

@app.route("/<name>") # sub-direcotry as variable pass to 
def user(name):       # return HTML template
    return f"<h1>Hello {name}</h1>"   # fill in as name

if __name__ == "__main__": 
    app.run(debug=True)
