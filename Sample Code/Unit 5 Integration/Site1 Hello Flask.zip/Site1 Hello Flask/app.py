from flask import Flask 
app = Flask(__name__)   # create Flask as app

@app.route("/")   # root directory of the site
def home():       # return HTML template
    return "<h1>Hello Flask</h1>"

if __name__ == "__main__": 
    app.run()
