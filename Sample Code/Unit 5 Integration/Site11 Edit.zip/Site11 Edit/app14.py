from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)   # create Flask as app
app.config['SECRET_KEY'] = 'fdahdfahlfa'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'

# Create Database
db = SQLAlchemy(app)

class Task(db.Model): 
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)

    def __repr__(self): 
        return f'{self.title} created on {self.date}'

db.create_all()
db.session.commit()

from routes import *    # same effects a the @app.route in app7.py

if __name__ == "__main__": 
    app.run(debug=True)
